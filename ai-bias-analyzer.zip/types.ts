export interface Metric {
  name: string;
  value: number;
  description: string;
  ideal: string;
}

export interface MetricSet {
  disparateImpact: Metric;
  statisticalParityDifference: Metric;
  equalOpportunityDifference: Metric;
}

export interface ChartDataPoint {
  group: string;
  'Favorable Outcome Rate': number;
}

export interface FeatureImportance {
  feature: string;
  importance: number;
  explanation: string;
}

export type AuditStep = 'initial' | 'pre-mitigation' | 'mitigating' | 'post-mitigation';

export type Demographic = 'Sex' | 'Race';