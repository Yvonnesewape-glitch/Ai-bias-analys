
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, TooltipProps } from 'recharts';
import { ChartDataPoint } from '../types';

interface BiasChartProps {
  data: ChartDataPoint[];
  title: string;
}

const CustomTooltip = ({ active, payload, label }: TooltipProps<number, string>) => {
  if (active && payload && payload.length) {
    return (
      <div className="p-3 bg-slate-700/80 backdrop-blur-sm border border-slate-600 rounded-md shadow-lg">
        <p className="font-bold text-slate-200 mb-1">{`Group: ${label}`}</p>
        <p className="text-blue-400">{`${payload[0].name}: `}<span className="font-semibold text-white">{`${(payload[0].value! * 100).toFixed(1)}%`}</span></p>
      </div>
    );
  }

  return null;
};


const BiasChart: React.FC<BiasChartProps> = ({ data, title }) => {
  return (
    <div className="bg-slate-800 p-6 rounded-lg shadow-lg border border-slate-700 h-96">
      <h3 className="text-lg font-bold text-blue-400 mb-4">{title}</h3>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{
            top: 5,
            right: 20,
            left: -10,
            bottom: 20,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
          <XAxis dataKey="group" stroke="#94a3b8" />
          <YAxis stroke="#94a3b8" tickFormatter={(value) => `${(value * 100).toFixed(0)}%`} />
          <Tooltip
            content={<CustomTooltip />}
            cursor={{ fill: 'rgba(31, 119, 180, 0.1)' }}
          />
          <Legend wrapperStyle={{ color: '#f1f5f9', paddingTop: '20px' }}/>
          <Bar dataKey="Favorable Outcome Rate" fill="#1f77b4" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default BiasChart;
