
import React from 'react';

interface SectionProps {
  title: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
}

const Section: React.FC<SectionProps> = ({ title, icon, children }) => {
  return (
    <section className="mb-12">
      <div className="flex items-center gap-3 mb-6">
        <div className="text-blue-400">{icon}</div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-200">{title}</h2>
      </div>
      {children}
    </section>
  );
};

export default Section;
