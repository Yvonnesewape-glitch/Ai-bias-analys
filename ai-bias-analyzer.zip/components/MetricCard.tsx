
import React, { useState, useCallback } from 'react';
import { Metric } from '../types';
import { getAIExplanation } from '../services/geminiService';
import { LightbulbIcon } from './icons';

interface MetricCardProps {
  metric: Metric;
  isPostMitigation: boolean;
  preMitigationValue?: number;
}

const MetricCard: React.FC<MetricCardProps> = ({ metric, isPostMitigation, preMitigationValue }) => {
  const [explanation, setExplanation] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleExplain = useCallback(async () => {
    setIsLoading(true);
    setExplanation('');
    const result = await getAIExplanation(metric);
    setExplanation(result);
    setIsLoading(false);
  }, [metric]);
  
  const valueChange = isPostMitigation && preMitigationValue !== undefined 
    ? metric.value - preMitigationValue 
    : 0;

  const isImproved = Math.abs(metric.value - (metric.ideal.includes('1.0') ? 1 : 0)) < Math.abs((preMitigationValue ?? metric.value) - (metric.ideal.includes('1.0') ? 1 : 0));
  
  const formattedValue = metric.value.toFixed(2);
  const formattedChange = valueChange.toFixed(2);

  return (
    <div className="bg-slate-800 p-4 rounded-lg shadow-lg border border-slate-700 flex flex-col justify-between h-full">
      <div>
        <h3 className="text-lg font-bold text-blue-400">{metric.name}</h3>
        <p className="text-sm text-slate-400 mt-1">{metric.description}</p>
        <p className="text-3xl font-mono font-bold my-4 text-white">{formattedValue}</p>
        {isPostMitigation && preMitigationValue !== undefined && (
          <div className={`text-sm flex items-center gap-1 ${isImproved ? 'text-green-500' : 'text-red-500'}`}>
             <span>{isImproved ? '▲' : '▼'}</span>
             <span>{formattedChange} (from {preMitigationValue.toFixed(2)})</span>
             <span className="font-semibold">{isImproved ? 'Improvement' : 'Worsened'}</span>
          </div>
        )}
        <p className="text-xs text-slate-500 mt-2">Ideal: {metric.ideal}</p>
      </div>

      <div className="mt-4">
        <button
          onClick={handleExplain}
          disabled={isLoading}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium rounded-md bg-blue-600 hover:bg-blue-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
        >
          <LightbulbIcon />
          {isLoading ? 'Thinking...' : 'Explain with AI'}
        </button>
        {explanation && (
          <div className="mt-3 p-3 bg-slate-900/50 rounded-md border border-slate-700">
            <p className="text-sm text-slate-300">{explanation}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MetricCard;
