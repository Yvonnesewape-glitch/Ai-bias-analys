
import React from 'react';

interface DashboardCardProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ title, icon, children, className = '' }) => {
  return (
    <div className={`bg-slate-800 p-4 rounded-lg shadow-lg border border-slate-700 h-full ${className}`}>
      <div className="flex items-center gap-3 mb-3">
        <div className="text-blue-400">{icon}</div>
        <h3 className="text-base font-semibold text-slate-300">{title}</h3>
      </div>
      <div className="text-slate-200">
        {children}
      </div>
    </div>
  );
};

export default DashboardCard;
