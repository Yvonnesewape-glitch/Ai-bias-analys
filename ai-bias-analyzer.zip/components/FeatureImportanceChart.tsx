
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LabelList } from 'recharts';
import { FeatureImportance } from '../types';

interface FeatureImportanceChartProps {
  data: FeatureImportance[];
  onBarClick: (data: FeatureImportance) => void;
}

const FeatureImportanceChart: React.FC<FeatureImportanceChartProps> = ({ data, onBarClick }) => {
  // Sort data to show the most important feature at the top
  const sortedData = [...data].sort((a, b) => b.importance - a.importance);

  return (
    <div className="bg-slate-800 p-6 rounded-lg shadow-lg border border-slate-700 h-96">
      <h3 className="text-lg font-bold text-blue-400 mb-2">Top 5 Biasing Features</h3>
      <p className="text-sm text-slate-400 mb-4">Click on a bar to see an explanation.</p>
      <ResponsiveContainer width="100%" height="90%">
        <BarChart
          layout="vertical"
          data={sortedData}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#475569" horizontal={false} />
          <XAxis type="number" stroke="#94a3b8" />
          <YAxis 
            type="category" 
            dataKey="feature" 
            stroke="#94a3b8" 
            width={120} 
            tick={{ fill: '#cbd5e1' }}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip
            cursor={{ fill: 'rgba(31, 119, 180, 0.1)' }}
            contentStyle={{
              backgroundColor: 'rgba(30, 41, 59, 0.8)',
              borderColor: '#475569',
              borderRadius: '0.5rem',
            }}
            labelStyle={{ color: '#f1f5f9' }}
          />
          <Bar 
            dataKey="importance" 
            fill="#1f77b4" 
            name="SHAP Value (Avg. Impact)" 
            barSize={20}
            onClick={(payload) => onBarClick(payload)}
          >
             <LabelList dataKey="importance" position="right" formatter={(value: number) => value.toFixed(2)} fill="#f1f5f9" />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default FeatureImportanceChart;
