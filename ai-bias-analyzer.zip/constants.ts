
import { MetricSet, ChartDataPoint, FeatureImportance } from './types';

export const PRE_MITIGATION_METRICS_SEX: MetricSet = {
  disparateImpact: {
    name: 'Disparate Impact',
    value: 0.44,
    description: 'Ratio of favorable outcomes for unprivileged vs. privileged groups.',
    ideal: 'Close to 1.0',
  },
  statisticalParityDifference: {
    name: 'Statistical Parity Difference',
    value: -0.19,
    description: 'Difference in favorable outcome rates.',
    ideal: 'Close to 0.0',
  },
  equalOpportunityDifference: {
    name: 'Equal Opportunity Difference',
    value: -0.21,
    description: 'Difference in true positive rates.',
    ideal: 'Close to 0.0',
  },
};

export const POST_MITIGATION_METRICS_SEX: MetricSet = {
  disparateImpact: {
    name: 'Disparate Impact',
    value: 0.85,
    description: 'Ratio of favorable outcomes for unprivileged vs. privileged groups.',
    ideal: 'Close to 1.0',
  },
  statisticalParityDifference: {
    name: 'Statistical Parity Difference',
    value: -0.08,
    description: 'Difference in favorable outcome rates.',
    ideal: 'Close to 0.0',
  },
  equalOpportunityDifference: {
    name: 'Equal Opportunity Difference',
    value: -0.05,
    description: 'Difference in true positive rates.',
    ideal: 'Close to 0.0',
  },
};

export const PRE_MITIGATION_CHART_DATA_SEX: ChartDataPoint[] = [
  { group: 'Male', 'Favorable Outcome Rate': 0.31 },
  { group: 'Female', 'Favorable Outcome Rate': 0.11 },
];

export const POST_MITIGATION_CHART_DATA_SEX: ChartDataPoint[] = [
  { group: 'Male', 'Favorable Outcome Rate': 0.28 },
  { group: 'Female', 'Favorable Outcome Rate': 0.24 },
];

export const PRE_MITIGATION_METRICS_RACE: MetricSet = {
  disparateImpact: {
    name: 'Disparate Impact',
    value: 0.55,
    description: 'Ratio of favorable outcomes for unprivileged vs. privileged groups.',
    ideal: 'Close to 1.0',
  },
  statisticalParityDifference: {
    name: 'Statistical Parity Difference',
    value: -0.25,
    description: 'Difference in favorable outcome rates.',
    ideal: 'Close to 0.0',
  },
  equalOpportunityDifference: {
    name: 'Equal Opportunity Difference',
    value: -0.28,
    description: 'Difference in true positive rates.',
    ideal: 'Close to 0.0',
  },
};

// FIX: Corrected typo in constant name from POST_MITigation_METRICS_RACE to POST_MITIGATION_METRICS_RACE
export const POST_MITIGATION_METRICS_RACE: MetricSet = {
  disparateImpact: {
    name: 'Disparate Impact',
    value: 0.91,
    description: 'Ratio of favorable outcomes for unprivileged vs. privileged groups.',
    ideal: 'Close to 1.0',
  },
  statisticalParityDifference: {
    name: 'Statistical Parity Difference',
    value: -0.05,
    description: 'Difference in favorable outcome rates.',
    ideal: 'Close to 0.0',
  },
  equalOpportunityDifference: {
    name: 'Equal Opportunity Difference',
    value: -0.03,
    description: 'Difference in true positive rates.',
    ideal: 'Close to 0.0',
  },
};

export const PRE_MITIGATION_CHART_DATA_RACE: ChartDataPoint[] = [
  { group: 'White', 'Favorable Outcome Rate': 0.38 },
  { group: 'Black', 'Favorable Outcome Rate': 0.13 },
];

export const POST_MITIGATION_CHART_DATA_RACE: ChartDataPoint[] = [
  { group: 'White', 'Favorable Outcome Rate': 0.32 },
  { group: 'Black', 'Favorable Outcome Rate': 0.28 },
];


export const PRE_MITIGATION_MODEL_PERFORMANCE = { accuracy: 0.85 };
export const POST_MITIGATION_MODEL_PERFORMANCE = { accuracy: 0.83 };

export const FEATURE_IMPORTANCE_SEX: FeatureImportance[] = [
  { feature: 'Occupation', importance: 0.28, explanation: 'Certain occupations are historically gender-dominated. The model may be learning this societal bias, associating "male-typical" jobs with higher income potential and "female-typical" jobs with lower potential, thus impacting loan approvals or hiring decisions unfairly.' },
  { feature: 'Hours per Week', importance: 0.21, explanation: 'On average, women may work fewer hours due to disproportionate caregiving responsibilities. The model could be penalizing applicants for working fewer than 40 hours, which indirectly discriminates against women.' },
  { feature: 'Marital Status', importance: 0.17, explanation: 'The model might have learned biased patterns where being "Married-civ-spouse" is a strong positive predictor, a status historically tied to men as primary breadwinners. This could disadvantage single women or those in other marital situations.' },
  { feature: 'Education Level', importance: 0.12, explanation: 'While seemingly neutral, if the dataset contains historical gender disparities in certain fields of study (e.g., fewer women in STEM), the model can penalize individuals for not having degrees that are more common among the privileged group.' },
  { feature: 'Age', importance: 0.09, explanation: 'Age can interact with gender in biased ways. For example, the model might unfairly penalize younger women (assuming career breaks for family) or older women (assuming they are less tech-savvy), patterns learned from historical data.' },
];

export const FEATURE_IMPORTANCE_RACE: FeatureImportance[] = [
  { feature: 'Education Level', importance: 0.31, explanation: 'Due to systemic inequalities, access to higher education may differ across racial groups. The model may be heavily weighing specific degrees that are less attainable for minority groups, thus creating a biased barrier.' },
  { feature: 'Zip Code / Geolocation', importance: 0.25, explanation: 'This feature is often a strong proxy for race due to residential segregation. The model could be learning to associate zip codes with predominantly minority populations with higher risk, leading to discriminatory outcomes in loan or insurance applications.' },
  { feature: 'Occupation', importance: 0.19, explanation: 'Similar to gender, racial groups can be over or underrepresented in certain occupations due to historical and systemic factors. Relying heavily on this feature can perpetuate existing inequalities.' },
  { feature: 'Capital Gains/Loss', importance: 0.15, explanation: 'Access to investment opportunities and generational wealth can vary significantly by race. The model may interpret the absence of capital gains as a negative signal, which disproportionately affects racial groups with less historical access to wealth.' },
  { feature: 'Relationship Status', importance: 0.08, explanation: 'Cultural and socioeconomic factors can influence family structures across different racial groups. If the model has learned that a certain relationship status is more "stable" or "favorable," it could inadvertently penalize groups where that status is less common.' },
];
