
import { GoogleGenAI } from "@google/genai";
import { Metric } from '../types';

if (!process.env.API_KEY) {
  console.warn("API_KEY environment variable not set. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAIExplanation = async (metric: Metric): Promise<string> => {
  if (!process.env.API_KEY) {
    return Promise.resolve("AI explanations are disabled. Please set the API_KEY environment variable.");
  }
  
  try {
    const prompt = `
      Explain the machine learning fairness metric "${metric.name}" in simple, easy-to-understand terms for a non-technical audience.
      Its purpose is: "${metric.description}".
      An ideal value is typically "${metric.ideal}".
      In our analysis, we observed a value of ${metric.value.toFixed(2)}.
      Based on this observed value, briefly explain what it indicates about fairness between groups.
      Keep the entire explanation to 2-3 concise sentences.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    return response.text;
  } catch (error) {
    console.error("Error fetching AI explanation:", error);
    return "Could not retrieve AI-powered explanation at this time.";
  }
};
