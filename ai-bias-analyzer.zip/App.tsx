import React, { useState, useCallback, useEffect } from 'react';
import {
  PRE_MITIGATION_METRICS_SEX,
  POST_MITIGATION_METRICS_SEX,
  PRE_MITIGATION_CHART_DATA_SEX,
  POST_MITIGATION_CHART_DATA_SEX,
  PRE_MITIGATION_METRICS_RACE,
  POST_MITIGATION_METRICS_RACE,
  PRE_MITIGATION_CHART_DATA_RACE,
  POST_MITIGATION_CHART_DATA_RACE,
  PRE_MITIGATION_MODEL_PERFORMANCE,
  POST_MITIGATION_MODEL_PERFORMANCE,
  FEATURE_IMPORTANCE_SEX,
  FEATURE_IMPORTANCE_RACE,
} from './constants';
import { AuditStep, Demographic, Metric, MetricSet, FeatureImportance } from './types';
import MetricCard from './components/MetricCard';
import BiasChart from './components/BiasChart';
import ComparisonChart from './components/ComparisonChart';
import FeatureImportanceChart from './components/FeatureImportanceChart';
import Section from './components/Section';
import LoadingSpinner from './components/LoadingSpinner';
import DashboardCard from './components/DashboardCard';
import { ChartBarIcon, CheckCircleIcon, DocumentTextIcon, ChevronDownIcon, ClipboardListIcon, SparklesIcon, DatabaseIcon, ScaleIcon, TrendingUpIcon, SearchCircleIcon, DownloadIcon } from './components/icons';

const AccordionItem: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="border border-slate-700 rounded-lg mb-2">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex justify-between items-center p-4 text-left font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-t-lg"
            >
                <span>{title}</span>
                <span className={`${isOpen ? 'rotate-180' : ''}`}><ChevronDownIcon /></span>
            </button>
            {isOpen && (
                <div className="p-4 bg-slate-800/50 rounded-b-lg">
                    {children}
                </div>
            )}
        </div>
    );
};

const storyContent = {
  Sex: {
    scenario: "Imagine this model is used by a bank to approve or deny loan applications. The initial analysis shows a significant risk that the model could unfairly deny loans to qualified female applicants simply because of their gender.",
    preMitigationInsights: {
      title: "Initial Findings: Key Insights",
      icon: <ClipboardListIcon />,
      points: [
        { title: "Top Bias Indicator", text: "⚠️ Disparate Impact is very low (0.44), suggesting a large disparity in outcomes." },
        { title: "Most Affected Group", text: "👥 The 'Female' demographic receives favorable outcomes at a much lower rate than the 'Male' group." },
        { title: "Recommended Action", text: "➡️ Apply bias mitigation techniques to correct for this inequity." }
      ]
    },
    postMitigationInsights: {
      title: "After Mitigation: Key Improvements",
      icon: <SparklesIcon />,
      points: [
        { title: "Significant Fairness Gain", text: "✅ All fairness metrics are now much closer to their ideal, equitable values." },
        { title: "Most Improved Metric", text: "📈 Disparate Impact improved from 0.44 to 0.85, indicating a much fairer outcome distribution." },
        { title: "Recommended Next Step", text: "🛡️ Implement continuous monitoring to ensure fairness is maintained over time." }
      ]
    }
  },
  Race: {
    scenario: "If this model were used to screen job applications, these biases could cause it to systematically filter out qualified candidates from the 'Black' demographic group, perpetuating workplace inequality.",
     preMitigationInsights: {
      title: "Initial Findings: Key Insights",
      icon: <ClipboardListIcon />,
      points: [
        { title: "Top Bias Indicator", text: "⚠️ Statistical Parity Difference is high (-0.25), indicating a significant difference in selection rates." },
        { title: "Most Affected Group", text: "👥 The 'Black' demographic group has a substantially lower favorable outcome rate compared to the 'White' group." },
        { title: "Recommended Action", text: "➡️ Deploy bias mitigation to address the identified disparities." }
      ]
    },
    postMitigationInsights: {
      title: "After Mitigation: Key Improvements",
      icon: <SparklesIcon />,
      points: [
        { title: "Achieved Parity", text: "✅ Fairness metrics like Statistical Parity Difference are now near zero, indicating equitable outcomes." },
        { title: "Most Improved Metric", text: "📈 Disparate Impact rose from a biased 0.55 to a much fairer 0.91." },
        { title: "Recommended Next Step", text: "🛡️ Continuously audit the model in production for any re-emerging bias." }
      ]
    }
  }
};


const reportContent = {
  Sex: {
    summary: "The initial analysis revealed significant bias against the 'Female' demographic group, as indicated by fairness metrics far from their ideal values. After applying the 'Reweighing' mitigation technique, all fairness metrics showed substantial improvement towards equity. For example, the Disparate Impact score improved from a low of 0.44 to a much fairer 0.85. This came with a minor trade-off in overall model accuracy, which slightly decreased from 85.0% to 83.0%, a common and often acceptable outcome in bias mitigation.",
    implications: "In a real-world scenario like loan or job application screening, the pre-mitigation bias would lead to systemic discrimination. Qualified female candidates would be unfairly rejected at a much higher rate than their male counterparts, perpetuating economic inequality and limiting opportunities. This not only harms individuals but also deprives organizations of diverse talent.",
    takeaways: "The mitigation strategy was highly effective. The Disparate Impact score, a key fairness indicator, improved by 93% (from 0.44 to 0.85), moving from 'High' severity bias to 'Low' severity. This was achieved with only a 2.35% decrease in overall model accuracy, representing a very favorable trade-off between fairness and performance."
  },
  Race: {
    summary: "The audit identified notable bias against the 'Black' demographic group compared to the 'White' group. Fairness metrics like Disparate Impact were well below the ideal threshold of 1.0. Implementing the 'Reweighing' strategy successfully corrected for this, bringing the Disparate Impact score from 0.55 to a much more equitable 0.91. This significant fairness gain was achieved with a minimal 2% reduction in the model's overall accuracy, demonstrating a positive trade-off.",
    implications: "Without mitigation, this model would disproportionately deny opportunities (e.g., loans, housing, employment) to Black individuals. This could reinforce historical disadvantages and create significant societal harm. Such a biased system could also lead to legal and reputational risks for the organization deploying it.",
    takeaways: "The 'Reweighing' technique successfully reduced bias. The Disparate Impact score saw a 65% improvement (from 0.55 to 0.91), and the Statistical Parity Difference was reduced by 80% (from -0.25 to -0.05). These significant gains in equity were balanced against a minimal 2.35% drop in model accuracy."
  }
};

const auditData = {
  Sex: {
    pre: { metrics: PRE_MITIGATION_METRICS_SEX, chart: PRE_MITIGATION_CHART_DATA_SEX, performance: PRE_MITIGATION_MODEL_PERFORMANCE },
    post: { metrics: POST_MITIGATION_METRICS_SEX, chart: POST_MITIGATION_CHART_DATA_SEX, performance: POST_MITIGATION_MODEL_PERFORMANCE },
    features: FEATURE_IMPORTANCE_SEX
  },
  Race: {
    pre: { metrics: PRE_MITIGATION_METRICS_RACE, chart: PRE_MITIGATION_CHART_DATA_RACE, performance: PRE_MITIGATION_MODEL_PERFORMANCE },
    post: { metrics: POST_MITIGATION_METRICS_RACE, chart: POST_MITIGATION_CHART_DATA_RACE, performance: POST_MITIGATION_MODEL_PERFORMANCE },
    features: FEATURE_IMPORTANCE_RACE
  }
};

const getSeverityInfo = (metric: Metric): { level: 'Low' | 'Moderate' | 'High', color: string } => {
    const value = metric.value;
    const absValue = Math.abs(value);
    
    if (metric.name === 'Disparate Impact') {
        if (absValue < 0.8 || absValue > 1.25) return { level: 'High', color: 'text-red-500' };
        if (absValue < 0.95 || absValue > 1.05) return { level: 'Moderate', color: 'text-orange-500' };
        return { level: 'Low', color: 'text-green-500' };
    } else { // For difference metrics, ideal is 0
        if (absValue > 0.1) return { level: 'High', color: 'text-red-500' };
        if (absValue > 0.05) return { level: 'Moderate', color: 'text-orange-500' };
        return { level: 'Low', color: 'text-green-500' };
    }
};


const App: React.FC = () => {
  const [step, setStep] = useState<AuditStep>('initial');
  const [selectedDemographic, setSelectedDemographic] = useState<Demographic>('Sex');
  const [selectedFeature, setSelectedFeature] = useState<FeatureImportance | null>(null);
  
  useEffect(() => {
    // Reset feature selection when demographic changes
    setSelectedFeature(null);
  }, [selectedDemographic]);

  const handleStartAudit = useCallback(() => {
    setStep('pre-mitigation');
  }, []);

  const handleMitigate = useCallback(() => {
    setStep('mitigating');
    setTimeout(() => {
      setStep('post-mitigation');
    }, 2500);
  }, []);
  
  const handleFeatureSelect = useCallback((feature: FeatureImportance) => {
    setSelectedFeature(feature);
  }, []);

  const handleDownloadReport = useCallback(() => {
    const isPost = step === 'post-mitigation';
    const currentAuditData = auditData[selectedDemographic];
    const dataSet = isPost ? currentAuditData.post : currentAuditData.pre;
    const preDataSet = currentAuditData.pre;

    let csvContent = "data:text/csv;charset=utf-8,";

    csvContent += `AI Bias Analysis Summary\n`;
    csvContent += `Demographic Attribute,${selectedDemographic}\n`;
    csvContent += `Stage,${isPost ? 'Post-Mitigation' : 'Pre-Mitigation'}\n\n`;

    csvContent += "Fairness Metrics\n";
    csvContent += "Metric,Value,Ideal Value\n";
    Object.values(dataSet.metrics).forEach(metric => {
        csvContent += `${metric.name},${metric.value.toFixed(3)},"${metric.ideal}"\n`;
    });
    csvContent += "\n";

    if(isPost) {
      csvContent += "Mitigation Impact on Metrics\n";
      csvContent += "Metric,Before,After,Change\n";
      (Object.keys(dataSet.metrics) as Array<keyof MetricSet>).forEach(key => {
        const postValue = dataSet.metrics[key].value;
        const preValue = preDataSet.metrics[key].value;
        const change = postValue - preValue;
        csvContent += `${dataSet.metrics[key].name},${preValue.toFixed(3)},${postValue.toFixed(3)},${change.toFixed(3)}\n`;
      });
      csvContent += "\n";
    }

    csvContent += "Favorable Outcome Rates by Group\n";
    csvContent += "Group,Favorable Outcome Rate\n";
    dataSet.chart.forEach(item => {
        csvContent += `${item.group},${item['Favorable Outcome Rate'].toFixed(3)}\n`;
    });
    csvContent += "\n";

    csvContent += "Model Performance\n";
    csvContent += "Metric,Value\n";
    csvContent += `Accuracy,${dataSet.performance.accuracy.toFixed(3)}\n`;
     if(isPost) {
        csvContent += `Accuracy (Before),${preDataSet.performance.accuracy.toFixed(3)}\n`;
     }
    csvContent += "\n";

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    const fileName = `AI_Bias_Analysis_${selectedDemographic}_${isPost ? 'Post_Mitigation' : 'Pre_Mitigation'}.csv`;
    link.setAttribute("download", fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

}, [step, selectedDemographic]);

  const renderContent = () => {
    if (step === 'initial') {
      return (
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-slate-100 sm:text-4xl">Welcome to the AI Bias Analyzer</h2>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-slate-400">
            Analyze fairness in machine learning. We will use the "Adult Census Income" dataset to identify, visualize, and mitigate bias related to protected attributes.
          </p>
          <button
            onClick={handleStartAudit}
            className="mt-8 px-8 py-3 text-lg font-semibold rounded-lg bg-blue-600 hover:bg-blue-500 transition-transform transform hover:scale-105"
          >
            Begin Audit
          </button>
        </div>
      );
    }
    
    if (step === 'mitigating') {
        return <LoadingSpinner size="lg" text="Applying mitigation techniques..." />;
    }

    const isPost = step === 'post-mitigation';
    const currentAuditData = auditData[selectedDemographic];
    const currentStory = storyContent[selectedDemographic];
    const insights = isPost ? currentStory.postMitigationInsights : currentStory.preMitigationInsights;

    const metrics = isPost ? currentAuditData.post.metrics : currentAuditData.pre.metrics;
    const chartData = isPost ? currentAuditData.post.chart : currentAuditData.pre.chart;
    const performance = isPost ? currentAuditData.post.performance : currentAuditData.pre.performance;
    const featureData = currentAuditData.features;

    return (
      <div className="w-full max-w-7xl">
        <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
            <div className="flex items-center justify-center md:justify-start gap-4 flex-wrap">
                <h3 className="text-xl font-semibold text-slate-300 self-center">Analyze by Protected Attribute:</h3>
                <div className="bg-slate-800 p-1 rounded-lg flex space-x-1 border border-slate-700">
                    {(['Sex', 'Race'] as Demographic[]).map(d => (
                        <button
                            key={d}
                            onClick={() => setSelectedDemographic(d)}
                            className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${
                                selectedDemographic === d 
                                ? 'bg-blue-600 text-white' 
                                : 'bg-transparent text-slate-300 hover:bg-slate-700'
                            }`}
                        >
                            {d}
                        </button>
                    ))}
                </div>
            </div>
            <button
                onClick={handleDownloadReport}
                className="flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors"
            >
                <DownloadIcon />
                Download Report
            </button>
        </div>
        
        <div className="mb-8 p-4 bg-blue-900/50 border border-blue-700 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold text-blue-300 mb-2">Real-World Scenario</h3>
            <p className="text-slate-300">{currentStory.scenario}</p>
        </div>
        
        <Section title="Audit Summary Dashboard" icon={<ClipboardListIcon />}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <DashboardCard title="Features Audited" icon={<DatabaseIcon />}>
                    <p className="text-4xl font-bold text-center mt-2">14</p>
                    <p className="text-sm text-slate-400 text-center mt-1">from Adult Census Dataset</p>
                </DashboardCard>

                <DashboardCard title="Bias Severity" icon={<ScaleIcon />}>
                    <div className="space-y-2 mt-2 text-sm">
                        {Object.values(metrics).map(metric => {
                            const severity = getSeverityInfo(metric);
                            return (
                                <div key={metric.name} className="flex justify-between items-center">
                                    <span className="text-slate-300">{metric.name}:</span>
                                    <span className={`font-bold px-2 py-0.5 rounded-full text-xs ${severity.color.replace('text-', 'bg-').replace('-500', '/20')} ${severity.color}`}>
                                        {severity.level}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                </DashboardCard>

                {isPost && (
                    <DashboardCard title="Mitigation Impact" icon={<TrendingUpIcon />}>
                        <div className="space-y-2 mt-2 text-sm">
                            {(Object.keys(metrics) as Array<keyof MetricSet>).map(metricKey => {
                                const postMetric = metrics[metricKey];
                                const preMetric = currentAuditData.pre.metrics[metricKey];
                                
                                const preValue = preMetric.value;
                                const postValue = postMetric.value;
                                const change = postValue - preValue;
                                const isImproved = Math.abs(postValue - (postMetric.ideal.includes('1.0') ? 1 : 0)) < Math.abs(preValue - (postMetric.ideal.includes('1.0') ? 1 : 0));
                                
                                return (
                                    <div key={postMetric.name} className="flex justify-between items-center">
                                        <span className="text-slate-300">{postMetric.name}:</span>
                                        <span className={`font-bold flex items-center gap-1 ${isImproved ? 'text-green-500' : 'text-red-500'}`}>
                                            {isImproved ? '▲' : '▼'} {change.toFixed(2)}
                                        </span>
                                    </div>
                                );
                            })}
                        </div>
                    </DashboardCard>
                )}
            </div>
        </Section>

        <Section title="Fairness Metrics Analysis" icon={<CheckCircleIcon />}>
            <div className="mb-6 bg-slate-800/50 p-6 rounded-lg border border-slate-700">
                <div className="flex items-center gap-3 mb-4">
                  <div className="text-blue-400">{insights.icon}</div>
                  <h3 className="text-xl font-bold text-slate-200">{insights.title}</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {insights.points.map(point => (
                    <div key={point.title}>
                      <h4 className="font-semibold text-slate-300">{point.title}</h4>
                      <p className="text-slate-400 text-sm">{point.text}</p>
                    </div>
                  ))}
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <MetricCard metric={metrics.disparateImpact} isPostMitigation={isPost} preMitigationValue={currentAuditData.pre.metrics.disparateImpact.value} />
                <MetricCard metric={metrics.statisticalParityDifference} isPostMitigation={isPost} preMitigationValue={currentAuditData.pre.metrics.statisticalParityDifference.value} />
                <MetricCard metric={metrics.equalOpportunityDifference} isPostMitigation={isPost} preMitigationValue={currentAuditData.pre.metrics.equalOpportunityDifference.value} />
            </div>
        </Section>
        
        <Section title="Explainability & Feature Analysis" icon={<SearchCircleIcon />}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <FeatureImportanceChart data={featureData} onBarClick={handleFeatureSelect} />
                <div className="bg-slate-800 p-6 rounded-lg shadow-lg border border-slate-700 h-96 flex flex-col justify-center">
                    {selectedFeature ? (
                        <>
                            <h3 className="text-lg font-bold text-blue-400 mb-2">Analysis for: <span className="text-white">{selectedFeature.feature}</span></h3>
                            <p className="text-slate-300">{selectedFeature.explanation}</p>
                        </>
                    ) : (
                        <div className="text-center">
                            <p className="text-slate-400">Click on a feature in the chart to the left to see an analysis of its potential contribution to model bias.</p>
                        </div>
                    )}
                </div>
            </div>
        </Section>

        <Section title={isPost ? "Bias Visualization: Before vs. After" : "Bias Visualization"} icon={<ChartBarIcon />}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
              {isPost ? (
                <ComparisonChart 
                  preData={currentAuditData.pre.chart}
                  postData={currentAuditData.post.chart}
                  title={`Favorable Outcome Rate by ${selectedDemographic}`} 
                />
              ) : (
                <BiasChart data={chartData} title={`Favorable Outcome Rate by ${selectedDemographic}`} />
              )}
              
              <div className="bg-slate-800 p-6 rounded-lg shadow-lg border border-slate-700 h-full flex flex-col justify-center">
                <h3 className="text-lg font-bold text-blue-400 mb-2 text-center">{isPost ? 'Model Performance Comparison' : 'Model Performance'}</h3>
                {isPost ? (
                  <>
                    <p className="text-slate-400 text-sm text-center mb-4">Bias mitigation can sometimes cause a slight trade-off in overall model accuracy.</p>
                    <div className="flex justify-around items-center text-center">
                        <div>
                            <p className="text-sm text-slate-400">Before Mitigation</p>
                            <p className="text-4xl font-mono font-bold text-slate-300">{(currentAuditData.pre.performance.accuracy * 100).toFixed(1)}%</p>
                        </div>
                        <div className={`text-2xl font-bold ${performance.accuracy < currentAuditData.pre.performance.accuracy ? 'text-orange-500' : 'text-green-500'}`}>
                            →
                        </div>
                        <div>
                            <p className="text-sm text-blue-400">After Mitigation</p>
                            <p className="text-4xl font-mono font-bold text-white">{(performance.accuracy * 100).toFixed(1)}%</p>
                        </div>
                    </div>
                    <div className="text-center mt-4">
                        <p className="text-lg font-semibold">
                            Change: 
                            <span className={`ml-2 ${performance.accuracy < currentAuditData.pre.performance.accuracy ? 'text-orange-500' : 'text-green-500'}`}>
                                {((performance.accuracy - currentAuditData.pre.performance.accuracy) * 100).toFixed(2)}%
                            </span>
                        </p>
                    </div>
                  </>
                ) : (
                  <>
                    <p className="text-slate-300 text-sm">Accuracy is a measure of the model's overall correctness. Sometimes, fairness interventions can have a slight impact on this metric.</p>
                    <div className="mt-4 text-center">
                        <p className="text-5xl font-mono font-bold text-white">{(performance.accuracy * 100).toFixed(1)}%</p>
                        <p className="text-sm text-slate-400">Overall Accuracy</p>
                    </div>
                     <button
                        onClick={handleMitigate}
                        className="mt-6 w-full px-6 py-3 text-base font-semibold rounded-lg bg-blue-600 hover:bg-blue-500 transition-transform transform hover:scale-105"
                    >
                        Apply Reweighing & Analyze
                    </button>
                  </>
                )}
              </div>
            </div>
        </Section>

        {isPost && (
            <Section title="Final Report & Recommendations" icon={<DocumentTextIcon />}>
                <div className="bg-slate-800 p-6 rounded-lg shadow-lg border border-slate-700 space-y-4 text-slate-300">
                   <h3 className="text-xl font-bold text-slate-100">Summary of Findings</h3>
                   <p>{reportContent[selectedDemographic].summary}</p>

                   <AccordionItem title="Key Quantitative Takeaways">
                       <p>{reportContent[selectedDemographic].takeaways}</p>
                   </AccordionItem>
                   
                   <AccordionItem title="Real-World Implications & Harms">
                       <p>{reportContent[selectedDemographic].implications}</p>
                   </AccordionItem>

                   <AccordionItem title="Recommendations for Improvement">
                       <ul className="list-disc list-inside space-y-2">
                           <li><strong>Data Collection:</strong> Gather more representative data for underrepresented groups to ensure the model trains on a balanced dataset.</li>
                           <li><strong>Feature Engineering:</strong> Explore features that are less correlated with the protected attribute while still being predictive of the outcome.</li>
                           <li><strong>Continuous Monitoring:</strong> Implement a system to continuously monitor the model's fairness metrics in production to detect and address any emerging biases over time.</li>
                       </ul>
                   </AccordionItem>

                   <AccordionItem title="Proposed Ethics Framework">
                       <div className="space-y-2">
                            <p><strong>1. Fairness:</strong> Actively measure and mitigate bias across demographic groups. Strive for equitable outcomes.</p>
                            <p><strong>2. Accountability:</strong> Clearly define ownership for the model's ethical performance. Document all bias audit and mitigation steps.</p>
                            <p><strong>3. Transparency:</strong> Be transparent with stakeholders about the potential for bias in the model and the steps taken to address it. Make audit results accessible.</p>
                       </div>
                   </AccordionItem>
                </div>
            </Section>
        )}
      </div>
    );
  };
  
  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans">
      <header className="bg-slate-900/50 backdrop-blur-lg sticky top-0 z-10 border-b border-slate-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <h1 className="text-3xl font-bold text-white">
            AI Bias <span className="text-blue-400">Analyzer</span>
          </h1>
          <p className="text-slate-400 mt-1">An Interactive Tool for Ethical AI Analysis</p>
        </div>
      </header>
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex justify-center items-center">
            {renderContent()}
        </div>
      </main>
      <footer className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center text-slate-500">
        <p>Built for the Tech Career Accelerator by a world-class senior frontend React engineer.</p>
      </footer>
    </div>
  );
};

export default App;